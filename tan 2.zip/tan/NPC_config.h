//
//  NPC_config.h
//  op
//
//  Created by BoBo W on 2025/5/29.
//
#define npc_fc 2
#define npc_rc 0.01
#define npc_oc 0.1
#define npc_sc 0.1
#define npc_randm 0.05
#define npc_ts 0.05
#define npc_bs 0.05
#define npc_es_sl 0.3
//#define npc_agg 10
#define npc_apAdv 1000000
#define npc_rps 3
#define npc_perFrame 20
#define npc_rigor 0.1
#define npc_bumping 0.5
//#define npc_bumping1 0.8
