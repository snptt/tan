//
//  light.h
//  op
//
//  Created by BoBo W on 2025/4/21.
//
#ifndef LIGHT_H
#define LIGHT_H
#include <glad/glad.h>
#include <GLFW/glfw3.h>

void setLight(Shader *ourShader, Camera *camera){
    ourShader->use(ourShader);
    // directional light
    ourShader->setVec3f(ourShader,"dirLight.direction", cubePosition[0]-camera->Position[0],cubePosition[1]-camera->Position[1],cubePosition[2]-camera->Position[2]);
    ourShader->setVec3f(ourShader,"dirLight.ambient", 0.1f, 0.1f, 0.1f);
    ourShader->setVec3f(ourShader,"dirLight.diffuse", 0.4f, 0.4f, 0.4f);
    ourShader->setVec3f(ourShader,"dirLight.specular", 0.5f, 0.5f, 0.5f);
    
    // spotLight
    ourShader->setVec3f(ourShader,"spotLight.position", camera->Position[0],camera->Position[1],camera->Position[2]);
    ourShader->setVec3f(ourShader,"spotLight.direction", camera->Front[0],camera->Front[1],camera->Front[2]);
    ourShader->setVec3f(ourShader,"spotLight.ambient", 0.0f, 0.0f, 0.0f);
    ourShader->setVec3f(ourShader,"spotLight.diffuse", 1.0f, 1.0f, 1.0f);
    ourShader->setVec3f(ourShader,"spotLight.specular", 1.0f, 1.0f, 1.0f);
    ourShader->setFloat(ourShader,"spotLight.constant", 1.0f);
    ourShader->setFloat(ourShader,"spotLight.linear", 0.01f);
    ourShader->setFloat(ourShader,"spotLight.quadratic", 0.032f);
    ourShader->setFloat(ourShader,"spotLight.cutOff", cos(glm_rad(14.5f)));
    ourShader->setFloat(ourShader,"spotLight.outerCutOff", cos(glm_rad(18.0f)));
}

void updateLight(Shader *ourShader, Camera *camera){
    ourShader->use(ourShader);
    ourShader->setVec3f(ourShader,"viewPos",camera->Position[0],camera->Position[1],camera->Position[2]);
    
    // directional light
    ourShader->setVec3f(ourShader,"dirLight.direction", cubePosition[0]-camera->Position[0],cubePosition[1]-camera->Position[1],cubePosition[2]-camera->Position[2]);
    
    // spotLight
    ourShader->setVec3f(ourShader,"spotLight.position", camera->Position[0],camera->Position[1],camera->Position[2]);
    ourShader->setVec3f(ourShader,"spotLight.direction", camera->Front[0],camera->Front[1],camera->Front[2]);
}

#endif
