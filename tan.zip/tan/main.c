//
//  main.c
//  tan
//
//  Created by BoBo W on 2025/4/3.
//
#include <stdio.h>
#include <stdbool.h>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <math.h>
#include "stb_image.h"
#include "shader.h"
#include <cglm/cglm.h>
#include "CAMERA.h"
#include "cube.h"
#include "snake.h"
#include "food.h"
#include "texture.h"
#include "light.h"

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void processInput(GLFWwindow *window);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
// settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

//camera
Camera camera;
Camera* pcam=&camera;
vec3 position = {0.0f, 0.0f, 3.0f};

bool firstMouse = true;
float lastX = SCR_WIDTH/2.0f, lastY = SCR_HEIGHT/2.0f;

// stores how much we're seeing of either texture
float mixValue = 0.2f;

float deltaTime = 0.0f; // 当前帧与上一帧的时间差
float lastFrame = 0.0f; // 上一帧的时间

//0diffuse 1specular
int Cube_textureU[2] = {0,1};
//head body tail
int Snake_diffuse_textureU[3] = {0,1,2};
int specular_textureU[3] = {12,13,14};
//head body tail
int Rot_diffuse_textureU[3][3] = {3,4,5,6,7,8,9,10,11};
//const int Rot_specular_textureU[3] = {9,10,11};
int collapse[]={};

bool spaceKey=0;
bool directionKey=0;

unsigned int snakeDiffuseTexture[3];
unsigned int rotDiffuseTexture[3][3];
unsigned int SpecularTexture[3];

////[0-head;1-body;2-tail][face;end;left;up;right]
//unsigned int snakeDiffuseTexture[3][5];
//unsigned int snakeSpecularTexture[3][5];
////[0-stat0;1-1;2-2][face;end;left;up;right]
//unsigned int rotDiffuseTexture[3][5];
//unsigned int rotSpecularTexture[3][5];

int Max;

int main(void)
{
    IniCub(&Cube);
    
    // 初始化 GLFW
    glfwInit();
    // 配置 OpenGL 上下文
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    //for apple
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
        
    // 创建窗口
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "first", NULL, NULL);
    if (window==NULL) {
        printf("Failed to creat GLFW window");
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    //隐藏鼠标
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    //注册鼠标回调函数
    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);
    
    // 初始化 GLAD
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        printf("Failed to initialize GLAD\n");
        return -1;
    }
    
    //启用深度缓冲
    glEnable(GL_DEPTH_TEST);
    
    //使用封装的Shader
    Shader cubeShader=IniSha("tan/vshader.vs", "tan/fshader.fs");
    Shader snakeShader=IniSha("tan/vshader_snake.vs", "tan/fshader_snake.fs");
    Shader foodShader=IniSha("tan/vshader_food.vs", "tan/fshader_food.fs");
    snakeShader.use(&snakeShader);
    int u_texture[16]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
    snakeShader.set1iv(&snakeShader,"u_textures",16,u_texture);
    
    //使图像不上下颠倒
    stbi_set_flip_vertically_on_load(true);
    
    //生成纹理
    unsigned int texture1,texture2;
    load_texture(&texture1, "tan/res/gr.jpeg", GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_NEAREST, GL_NEAREST, Cube_textureU[0]);
    load_texture(&texture2, "tan/res/black.png", GL_REPEAT, GL_REPEAT, GL_LINEAR_MIPMAP_NEAREST, GL_NEAREST, Cube_textureU[1]);
    
    //注意颜色通道
    geterro(main122)
    TextureGenerate_cubeMap_SR(snakeDiffuseTexture, rotDiffuseTexture[0], SpecularTexture, Snake_diffuse_textureU, Rot_diffuse_textureU, specular_textureU);
    geterro(main123)
    
    setCubeMaterial(&cubeShader, Cube_textureU[0], Cube_textureU[1], 1.0);
    
    rotHandle->post=NULL;
    //camera初始化
    IniCam_vec(&camera, &position, &_UP, YAW, PITCH, 3);
    
    creatSnake(0, _snakeWIDTH, D(u(80)), 0.5, 0.5, C, B, _snakeV, NULL, 0, D(u(20)), 1);
//    creatSnake(0, D(u(100)), D(u(100)), 0.5, 0.5, C, B, _snakeV, NULL, 0, D(u(80)), 1);
    
    foodIni();
    
    debugp(main114, &snakeTransFinalH);
    debugp(main115, snakeH.headMat)
    
    Max=FragmentMax;
    geterro(main135)
    //for cube
    //创建顶点数组对象(VAO)
    unsigned int cubeVAO;
    glGenVertexArrays(1, &cubeVAO);
    //创建顶点缓冲对象(VBO)
    unsigned int cubeVBO;
    glGenBuffers(1, &cubeVBO);
    //绑定cubeVBO
    glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
    //传输ARRAY_BUFFER数据
    glBufferData(GL_ARRAY_BUFFER, sizeof(_cubeVertices), _cubeVertices, GL_STATIC_DRAW);
    //绑定cubeVAO
    glBindVertexArray(cubeVAO);
    //绑定cubeVBO
    glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
    geterro(main151)
    //如何解析顶点数据
    /*每个顶点属性从一个VBO管理的内存中获得它的数据，而具体是从哪个VBO（程序中可以有多个VBO）获取则是通过在调用glVertexAttribPointer时绑定到GL_ARRAY_BUFFER的VBO决定的。*/
    //位置属性
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 12 * sizeof(float), (void*)0);
    //颜色属性
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 12 * sizeof(float), (void*)(4*sizeof(float)));
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 12 * sizeof(float), (void*)(7*sizeof(float)));
    glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, 12 * sizeof(float), (void*)(10*sizeof(float)));
    geterro(main160)
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glEnableVertexAttribArray(2);
    glEnableVertexAttribArray(3);
    //解绑cubeVAO
    glBindVertexArray(0);
    //解绑
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    
    //0Ver 1model 2shininess 3diffuse 4specular
    unsigned int VAO_SR, VBO_SR[5];
    debugi(170, Max)
    geterro(main174)
    generateVAOVBO_SR(&VBO_SR[0], &VBO_SR[1], &VBO_SR[2], &VBO_SR[3], &VBO_SR[4], &VAO_SR, Max);
    geterro(main175)
        
    //0Ver 1model
    unsigned int VAO_F, VBO_F[2];
    generateVAOVBO_F(&VBO_F[0], &VBO_F[1], &VAO_F, foodNum);
    
    //trans
    mat4 View,Proj;
    glm_perspective(glm_rad(45.0f), (float)SCR_WIDTH/(float)SCR_HEIGHT, 0.1f, 100.0f, Proj);
    camera.GetViewMatrix(&camera, &View);
    
    cubeDrawSetting(&cubeShader, cubeVAO, (float*)View, (float*)Proj);

    setLight(&cubeShader, &camera);
    setLight(&snakeShader, &camera);
    
    //面剔除
    glEnable(GL_CULL_FACE);
    
    int i=-1;
//    debugmat3(main170,facingMatX)
//    glm_mat4_mul(facingMatZ4, facingMatZ4, test);
//    glm_mat4_mul(test, facingMatX4, test);
//    glm_mat4_mul(test, facingMatX4, test);
//    glm_mat4_mul(test, facingMatX4, test);
//    debugmat4(main175, test)
//    glm_mat4_copy(facingMatY, test);
    
    float fpstemp=0;
    
    int angle=0;
    
    int foodN=0;
    
    while(!glfwWindowShouldClose(window))
    {
        
        if(pauseEvent)while(pauseEvent&&!glfwWindowShouldClose(window)){
            float currentFrame = (float)glfwGetTime();
            deltaTime = currentFrame - lastFrame;
            lastFrame = currentFrame;
            processInput(window);
            glClearColor(0.5f, 0.8f, 1.0f, 1.0f);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            glm_perspective(glm_rad(45.0f), (float)SCR_WIDTH/(float)SCR_HEIGHT, 0.1f, 100.0f, Proj);
            updateLight(&cubeShader, &camera);
            updateLight(&snakeShader, &camera);
            cubeDraw(&cubeShader, &camera,cubeVAO, (float*)Proj);
//            snakeDraw(&snakeH, &snakeShader, &camera, &Proj, snakeVAO, Snake_diffuse_textureU, Snake_specular_textureU, snakeDiffuseTexture, snakeSpecularTexture);
            foodRefreshAll();
        
            drawF(&foodShader, &VBO_F[1], &VAO_F, &camera, &Proj, &foodN);
            rotUpdate();
//            rotDraw(&rotShader, &camera, &Proj, snakeVAO, Snake_diffuse_textureU, Snake_specular_textureU, snakeDiffuseTexture, snakeSpecularTexture);
            drawSR(&snakeShader, &VBO_SR[1], &VBO_SR[2], &VBO_SR[3], &VBO_SR[4], Snake_diffuse_textureU, Rot_diffuse_textureU, specular_textureU, &VAO_SR, &camera, &Proj);
            // 交换缓冲并查询IO事件
            glfwSwapBuffers(window);
            glfwPollEvents();
        };
        
        float currentFrame = (float)glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;
        //printf("deltaTime%f\n",deltaTime);
     
        if(i<fpscon){
            fpstemp+=deltaTime;
            i++;
        }else if(i==fpscon){
            fps=fpscon/fpstemp;
            fpstemp=0;
            i=0;
        }
        
//        angle++;
//        angle=angle%360;
        
        processInput(window);
        
        glClearColor(0.5f, 0.8f, 1.0f, 1.0f);
        //glClear(GL_COLOR_BUFFER_BIT);
        //清除深度缓冲
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
        vec3 pos;
        getAbsPos(snakeH.up, snakeH.direction, snakeH.advance+getLength(snakeH.eatProcess[0])/cube->size, snakeH.position, snakeH.mesa, pos);
        debugvec3(main260, pos)
        setTargetPos(&camera, pos);
        cameraUpdate(&camera, pos, angle, deltaTime);
        debugvec3(main262, camera.targetPosition)
        debugvec3(main262, camera.Position)
        debugvec3(main262, camera.Front)
        
        glm_perspective(glm_rad(45.0f), (float)SCR_WIDTH/(float)SCR_HEIGHT, 0.1f, 100.0f, Proj);
        
        updateLight(&cubeShader, &camera);
        updateLight(&snakeShader, &camera);
        updateLight(&foodShader, &camera);

//        rebindtextureU(collapse, Cube_textureU, sizeof(collapse)/sizeof(int), 2, &texture1, GL_TEXTURE_2D);
        cubeDraw(&cubeShader, &camera,cubeVAO, (float*)Proj);
//        cubeShader.use(&cubeShader);
//        glBindVertexArray(cubeVAO);
//        camera.GetViewMatrix(&camera, &View);
//        cubeShader.setMat4fv(&cubeShader, "view", (float*)snakeH.headMat);
//        debugmat4(188, *snakeH.headTrans1Mat)
//        debugmat4(188, *snakeH.headMat)
//        cubeShader.setMat4fv(&cubeShader,"proj",(float*)Proj);
//        glDrawArrays(GL_TRIANGLES, 0, 180);
//        glBindVertexArray(0);
        debugf(main193, getLength(snakeH.length));
        
        if(pause==1)snakeH.velocity=0;
        
        foodRefreshAll();
    
        drawF(&foodShader, &VBO_F[1], &VAO_F, &camera, &Proj, &foodN);
            
        debugp(main184, snakeH.headMat)
        rotUpdate();
        snakeUpdate(&snakeH, snakeH.velocity, deltaTime);
//        snakeDraw(&snakeH, &snakeShader, &camera, &Proj, snakeVAO, Snake_diffuse_textureU, Snake_specular_textureU, snakeDiffuseTexture, snakeSpecularTexture);
//        rotDraw(&snakeShader, &camera, &Proj, snakeVAO, Rot_diffuse_textureU, Rot_specular_textureU, rotDiffuseTexture, rotSpecularTexture);
//        rebindtextureU(collapse, Snake_diffuse_textureU, sizeof(collapse)/sizeof(int), 3, snakeDiffuseTexture, GL_TEXTURE_CUBE_MAP);
        drawSR(&snakeShader, &VBO_SR[1], &VBO_SR[2], &VBO_SR[3], &VBO_SR[4], Snake_diffuse_textureU, Rot_diffuse_textureU, specular_textureU,&VAO_SR, &camera, &Proj);
        debugf(main161,getLength(snakeH.toBeElongation))
        debugSnakePos(main224, (&snakeH))
        printf("fps%f\n",fps);
        
        
        // 交换缓冲并查询IO事件
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    
    //optional: de-allocate all resources
    glDeleteVertexArrays(1, &cubeVAO);
    glDeleteBuffers(1, &cubeVBO);
//    glDeleteBuffers(1, &EBO);
    
    glfwTerminate();
    return 0;
}

void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

void processInput(GLFWwindow *window)
{
    if(glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS){
        snakeFree(&snakeH);
        rotFree();
        glfwSetWindowShouldClose(window, true);
    }
    
    if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS){
            mixValue += 0.001f; // change this value accordingly (might be too slow or too fast based on system hardware)
            if(mixValue >= 1.0f)
                mixValue = 1.0f;
    }
    if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS)
    {
        mixValue -= 0.001f; // change this value accordingly (might be too slow or too fast based on system hardware)
        if (mixValue <= 0.0f)
            mixValue = 0.0f;
    }
    
//    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
//        camera.ProcessKeyboard(&camera, FORWARD, deltaTime);
//    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
//        camera.ProcessKeyboard(&camera, BACKWARD, deltaTime);
//    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
//        camera.ProcessKeyboard(&camera, LEFT, deltaTime);
//    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
//        camera.ProcessKeyboard(&camera, RIGHT, deltaTime);
//    
//    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
//        camera.ProcessKeyboard(&camera, FORWARD, deltaTime);
//    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
//        camera.ProcessKeyboard(&camera, BACKWARD, deltaTime);
//    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
//        camera.ProcessKeyboard(&camera, LEFT, deltaTime);
//    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
//        camera.ProcessKeyboard(&camera, RIGHT, deltaTime);
    
    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS && directionKey==0){
        snakeKeyBoard(&snakeH, _RIGHT);
//        directionKey=1;
    }
    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_RELEASE){
        directionKey=0;
    }
    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS && directionKey==0){
        snakeKeyBoard(&snakeH, _LEFT);
//        directionKey=1;
    }
    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_RELEASE){
        directionKey=0;
    }
    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS && spaceKey==0){
        snakeKeyBoard(&snakeH, _SPACE);
        spaceKey=1;
    }
    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_RELEASE && spaceKey==1){
        spaceKey=0;
    }
    if (glfwGetKey(window, GLFW_KEY_T) == GLFW_PRESS)
        snakeH.velocity=0;
    if (glfwGetKey(window, GLFW_KEY_C) == GLFW_PRESS)
        snakeH.velocity=_snakeV;
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
        pauseEvent=0;
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        pauseEvent=1;
    if (glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS)
        RpauseEvent=1;

    if (glfwGetKey(window, GLFW_KEY_F) == GLFW_PRESS)
    {
        pause=0;
        snakeH.velocity=_snakeV;
    }
}
void mouse_callback(GLFWwindow* window, double xposIn, double yposIn)
{
    if(glfwGetMouseButton(window,GLFW_MOUSE_BUTTON_LEFT)==GLFW_PRESS){
        float xpos = (float) trunc(xposIn), ypos = (float) trunc(yposIn);
        if(firstMouse)
        {
            lastX = xpos;
            lastY = ypos;
            firstMouse = false;
        }

        float xoffset = xpos - lastX;
        float yoffset = lastY - ypos;
        lastX = xpos;
        lastY = ypos;

        camera.ProcessMouseMovement(&camera,xoffset,yoffset,1);
    }
}
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    camera.ProcessMouseScroll(&camera, (float)trunc(yoffset));
}
