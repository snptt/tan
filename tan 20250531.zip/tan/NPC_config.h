//
//  NPC_config.h
//  op
//
//  Created by BoBo W on 2025/5/29.
//
#define npc_fc 1.5
#define npc_rc 0.01
#define npc_oc 0.1
#define npc_sc 0.2
#define npc_randm 0.1
#define npc_ts 0.1
#define npc_bs 0.1
#define npc_es_sl 0.2
//#define npc_agg 10
#define npc_apAdv 10000000
#define npc_rps 3
#define npc_perFrame 5
#define npc_rigor 0.5
